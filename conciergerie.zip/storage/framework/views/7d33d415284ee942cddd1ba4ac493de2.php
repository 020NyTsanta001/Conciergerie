<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Hoxen - Concièrgerie d'élite</title>
        <script>window.__MONEY__ = <?php echo json_encode(['usd_rate' => config('money.usd_rate')], 15, 512) ?>;</script>
        <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.jsx']); ?>
        <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('images/logo-white.svg')); ?>">
</head>
<body class="bg-white text-neutral-900 antialiased">
    <div id="root"></div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\conciergerie\resources\views/app.blade.php ENDPATH**/ ?>
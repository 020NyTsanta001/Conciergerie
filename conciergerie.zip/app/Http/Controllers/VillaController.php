<?php

namespace App\Http\Controllers;

use App\Http\Resources\VillaResource;
use App\Models\Villa;
use Illuminate\Http\Request;

class VillaController extends Controller
{
    public function index(Request $request)
    {
        // Mode « sélection aléatoire » : GET /properties?random=5
        if ($request->filled('random')) {
            $n = min(max((int) $request->query('random'), 1), 12);

            return VillaResource::collection(
                Villa::approved()
                    ->whereHas('images')          // uniquement des villas avec au moins une photo
                    ->with('images')
                    ->filter($request->query())
                    ->inRandomOrder()
                    ->limit($n)
                    ->get()
            );
        }


        // Eager loading : évite le problème N+1 (une requête pour les images de toute la page)
        $villas = Villa::approved()->with('images')
            ->filter($request->query())
            ->latest()
            ->paginate(12)
            ->withQueryString();

        return VillaResource::collection($villas);
    }

    public function show(Villa $villa)
    {
        abort_unless($villa->status === 'approved', 404);

        return new VillaResource($villa->load(['images', 'owner']));
    }

    /** GET /yachts : jusqu'à 4 yachts au hasard, parmi les villas approuvées qui en ont un */
    public function yachts()
    {
        return Villa::approved()
            ->where('has_yacht', true)
            ->whereNotNull('yacht_image')
            ->inRandomOrder()
            ->limit(4)
            ->get(['id', 'title', 'city', 'country', 'yacht_image', 'yacht_name', 'yacht_description', 'yacht_places'])
            ->map(fn ($v) => [
                'villa_id' => $v->id,
                'villa_title' => $v->title,
                'city' => $v->city,
                'country' => $v->country,
                'image' => $v->yacht_image,
                'name' => $v->yacht_name ?: 'Yacht de '.$v->title,
                'description' => $v->yacht_description,
                'places' => $v->yacht_places ?? [],
            ]);
    }
}

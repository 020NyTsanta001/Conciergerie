<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $fillable = ['name', 'email', 'password', 'role', 'phone'];

    protected $hidden = ['password', 'remember_token'];

    protected function casts(): array
    {
        return ['email_verified_at' => 'datetime', 'suspended_at' => 'datetime', 'balance' => 'integer', 'password' => 'hashed'];
    }

    public function villas() { return $this->hasMany(Villa::class, 'owner_id'); }

    public function bookings() { return $this->hasMany(Booking::class); }

    public function images() { return $this->morphMany(Image::class, 'imageable'); }
}
